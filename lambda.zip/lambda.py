def lambda_handler(event , context):
    print("Hello Raj from Terraform apigateway lab")
    return"Hello Raj from Terraform apigateway lab"